package edu.hos.model;

public interface pay_method {
	
	public String pay();

}
