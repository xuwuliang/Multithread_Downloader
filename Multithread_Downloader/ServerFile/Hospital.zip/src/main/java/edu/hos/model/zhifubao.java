package edu.hos.model;

public class zhifubao implements pay_method {

	@Override
	public String pay() {
		
		return "֧����";
	}

}
