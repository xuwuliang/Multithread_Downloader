package edu.hos.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import edu.hos.model.Scheduling;
@Repository
public interface SchedulingJdbcRepostiory {
	
	public List<Scheduling> findScheduling(int do_id,String sc_date);
	public int delectnum(int sc_id);

}
