package edu.hos.rest;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.hos.model.Doctor;
import edu.hos.model.Patient;
import edu.hos.model.Scheduling;
import edu.hos.model.Source_number;
import edu.hos.model.operation;
import edu.hos.model.register_record;
import edu.hos.repository.SchedulingJdbcRepostiory;
import edu.hos.repository.Source_numberJdbcRepository;
import edu.hos.repository.doctorJdbcRepository;
import edu.hos.repository.paJdbcRepository;
import edu.hos.repository.register_recordJdbcRepository;


@RequestMapping("/hos")
@RestController
public class HosRestController {
	@Autowired
	private paJdbcRepository pj;
	@Autowired
	private doctorJdbcRepository dj;
	@Autowired
	private SchedulingJdbcRepostiory sj;
	@Autowired
	private Source_numberJdbcRepository snj;
	@Autowired
	private register_recordJdbcRepository rrj;
	@GetMapping("/patient/{pa_card}/{password}")
	public Patient findpabyidandpassword(@PathVariable String pa_card,@PathVariable String password) {
		Patient p = new Patient(pa_card, password);
		return pj.findpabyidandpassword(p);
	}
	@PostMapping("/patient/")
	public int updateaccount_balance(@RequestBody Patient p ){
		if(pj.findpabyid(p.getPa_card())==1)
			return 0;//ע��ʧ�ܣ��û��Ѿ�ע����
		return pj.insertpa(p);
	}
	@GetMapping("/doctor/{de_id}/{sc_date}/{snt_id}")
	public List<Doctor> findDoctor(@PathVariable int de_id,@PathVariable String sc_date,@PathVariable int snt_id) {
		return operation.delectdoctor(dj.findDoctor(de_id, sc_date, snt_id));
	}
	@GetMapping("/Scheduling/{do_id}/{sc_date}")//��ѯʱ��Σ���Դ��
	public List<Scheduling> findScheduling(@PathVariable int do_id,@PathVariable String sc_date) {
		return sj.findScheduling(do_id, sc_date);
	}
	@GetMapping("/Source_number/{sc_id}")
	public Source_number findSource_number(@PathVariable int sc_id) {
		return snj.findSource_number(sc_id);
	}
	@GetMapping("/Scheduling/delect/{sc_id}")
	public int delectnum(@PathVariable int sc_id) {
		//System.out.println("sc_id��"+sc_id);
		return sj.delectnum(sc_id);
	}
	@PostMapping("/register_record/")
	public int insert(@RequestBody register_record record) {
		//System.out.println(record);
		return rrj.insert(record);

		
	}
	@GetMapping("/register_record/{pa_card}")
	public List<register_record> query(@PathVariable String pa_card) {
		return rrj.query(pa_card);
	}


}
