package edu.hos.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import edu.hos.model.Scheduling;
import edu.hos.model.Source_number;
@Component
public class Source_numberJdbcRepositoryImpl implements Source_numberJdbcRepository {
	@Autowired
	private JdbcTemplate jt;
	@Override
	public Source_number findSource_number(int sc_id) {
		try {
			return (Source_number)jt.queryForObject("select * from Source_number where sc_id=? ", new BeanPropertyRowMapper(Source_number.class),sc_id);
			
		} catch (EmptyResultDataAccessException e) {
			// TODO: hadministratorandle exception
			return null;
		}
		
	}

}
