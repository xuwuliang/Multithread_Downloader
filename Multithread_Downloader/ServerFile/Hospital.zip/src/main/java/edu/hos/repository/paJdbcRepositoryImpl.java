package edu.hos.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import edu.hos.model.Patient;

@Component
public class paJdbcRepositoryImpl implements paJdbcRepository {
	@Autowired
	private JdbcTemplate jt;

	@Override
	public Patient findpabyidandpassword(Patient p) {
		try {
			return (Patient) jt.queryForObject("select * from patient where pa_card=? and password=?",
					new BeanPropertyRowMapper(Patient.class), p.getPa_card(), p.getPassword());
		} catch (EmptyResultDataAccessException e) {
			// TODO: hadministratorandle exception
			return null;
		}

	}

	@Override
	public int insertpa(Patient p) {
		jt.update("insert into patient values(null,'Ĭ��',?,0,?)", p.getPa_card(), p.getPassword());
		return 1;
	}

	@Override
	public int findpabyid(String pa_card) {
		try {
			Patient pa = (Patient) jt.queryForObject("select * from patient where pa_card=?",
					new BeanPropertyRowMapper(Patient.class), pa_card);
			return 1;
		} catch (EmptyResultDataAccessException e) {
			// TODO: hadministratorandle exception
			return 0;
		}

	}

}
