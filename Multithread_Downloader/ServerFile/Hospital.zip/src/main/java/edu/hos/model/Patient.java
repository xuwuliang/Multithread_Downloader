package edu.hos.model;

public class Patient {
	
	private int  pa_id;//����ID
	  private String pa_name;//��������
	  private String pa_card;//��������֤��         
	  private int  pa_num;//ˬԼ
	  private String password;//����
	  public Patient() {
		  
	  }
	public Patient(int pa_id, String pa_name, String pa_card, int pa_num, String password) {
		super();
		this.pa_id = pa_id;
		this.pa_name = pa_name;
		this.pa_card = pa_card;
		this.pa_num = pa_num;
		this.password = password;
	}
	
	public Patient(String pa_card, String password) {
		super();
		this.pa_card = pa_card;
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getPa_id() {
		return pa_id;
	}
	public void setPa_id(int pa_id) {
		this.pa_id = pa_id;
	}
	public String getPa_name() {
		return pa_name;
	}
	public void setPa_name(String pa_name) {
		this.pa_name = pa_name;
	}
	public String getPa_card() {
		return pa_card;
	}
	public void setPa_card(String pa_card) {
		this.pa_card = pa_card;
	}
	public int getPa_num() {
		return pa_num;
	}
	public void setPa_num(int pa_num) {
		this.pa_num = pa_num;
	}
	  

}
