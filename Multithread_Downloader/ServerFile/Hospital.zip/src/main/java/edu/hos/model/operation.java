package edu.hos.model;

import java.util.ArrayList;
import java.util.List;

public class operation {
	
	public static List<Doctor> delectdoctor(List<Doctor> list){
		List<Doctor> newlist = new ArrayList<Doctor>();
		for(Doctor d :list) {
			if(!inlist(newlist,d)) {
				newlist.add(d);
			}
		}
		
		return newlist;
		
	}
	public static boolean inlist(List<Doctor> list,Doctor d ) {
		for(Doctor doc :list) {
			if(doc.getDo_id()==d.getDo_id()) {
				return true;
			}
		}
		return false;
	}

}
