package edu.hos.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import edu.hos.model.register_record;

@Repository
public interface register_recordJdbcRepository {
	public int insert(register_record record);
	public List<register_record> query(String pa_card);

}
