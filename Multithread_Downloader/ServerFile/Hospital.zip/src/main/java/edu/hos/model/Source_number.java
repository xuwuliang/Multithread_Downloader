package edu.hos.model;

public class Source_number {
	private int sn_id;//��Դ���
	private Source_number_state  ss;//��Դ״̬
	  private int sc_id;//�Ű���
	   private float sn_price;//�۸�
	   private String snt_name;//��Դ��������
	   public Source_number() {
		   
	   }
	public Source_number(int sn_id, Source_number_state ss, int sc_id, float sn_price, String snt_name) {
		super();
		this.sn_id = sn_id;
		this.ss = ss;
		this.sc_id = sc_id;
		this.sn_price = sn_price;
		this.snt_name = snt_name;
	}
	public int getSn_id() {
		return sn_id;
	}
	public void setSn_id(int sn_id) {
		this.sn_id = sn_id;
	}
	public Source_number_state getSs() {
		return ss;
	}
	public void setSs(Source_number_state ss) {
		this.ss = ss;
	}
	public int getSc_id() {
		return sc_id;
	}
	public void setSc_id(int sc_id) {
		this.sc_id = sc_id;
	}
	public float getSn_price() {
		return sn_price;
	}
	public void setSn_price(float sn_price) {
		this.sn_price = sn_price;
	}
	public String getSnt_name() {
		return snt_name;
	}
	public void setSnt_name(String snt_name) {
		this.snt_name = snt_name;
	}

}
