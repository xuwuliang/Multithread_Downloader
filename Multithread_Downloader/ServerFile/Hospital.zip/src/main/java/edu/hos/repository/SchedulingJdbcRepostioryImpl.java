package edu.hos.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import edu.hos.model.Doctor;
import edu.hos.model.Scheduling;

@Component
public class SchedulingJdbcRepostioryImpl implements SchedulingJdbcRepostiory{
	@Autowired
	private JdbcTemplate jt;
	@Override
	public List<Scheduling> findScheduling(int do_id, String sc_date) {
		try {
			return jt.query("select * from Scheduling where do_id=? and sc_date=? ", new BeanPropertyRowMapper(Scheduling.class),do_id,sc_date);
			
		} catch (EmptyResultDataAccessException e) {
			// TODO: hadministratorandle exception
			return null;
		}
		
	}
	@Override
	public int delectnum(int sc_id) {
		jt.update("update Scheduling set sn_num=sn_num-1 where sc_id=? ",sc_id);
		return 1;
	}

}
