package edu.hos.model;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class register_record {
	private int r_id;//���
	  private String  do_name;//ҽ������
	  private String pa_card;//��������֤��
	  private String rs_name;//״̬����
	  private String  con_name;//����
	  private Timestamp  r_date;//����
	  private String  r_time;//ʱ���
	  private String pay_method;//֧����ʽ
	  private float pay_money;//���         
	  public register_record() {
		  
	  }
	
	public register_record(int r_id, String do_name, String pa_card, String rs_name, String con_name, Timestamp r_date,
			String r_time, String pay_method, float pay_money) {
		super();
		this.r_id = r_id;
		this.do_name = do_name;
		this.pa_card = pa_card;
		this.rs_name = rs_name;
		this.con_name = con_name;
		this.r_date = r_date;
		this.r_time = r_time;
		this.pay_method = pay_method;
		this.pay_money = pay_money;
	}

	public String getCon_name() {
		return con_name;
	}

	public void setCon_name(String con_name) {
		this.con_name = con_name;
	}

	public int getR_id() {
		return r_id;
	}
	public void setR_id(int r_id) {
		this.r_id = r_id;
	}
	public String getDo_name() {
		return do_name;
	}
	public void setDo_name(String do_name) {
		this.do_name = do_name;
	}
	public String getPa_card() {
		return pa_card;
	}
	public void setPa_card(String pa_card) {
		this.pa_card = pa_card;
	}
	public String getRs_name() {
		return rs_name;
	}
	public void setRs_name(String rs_name) {
		this.rs_name = rs_name;
	}
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Timestamp getR_date() {
		return r_date;
	}
	public void setR_date(Timestamp r_date) {
		this.r_date = r_date;
	}
	public String getR_time() {
		return r_time;
	}
	public void setR_time(String r_time) {
		this.r_time = r_time;
	}
	public String getPay_method() {
		return pay_method;
	}
	public void setPay_method(String pay_method) {
		this.pay_method = pay_method;
	}
	public float getPay_money() {
		return pay_money;
	}
	public void setPay_money(float pay_money) {
		this.pay_money = pay_money;
	}

	@Override
	public String toString() {
		return "register_record [r_id=" + r_id + ", do_name=" + do_name + ", pa_card=" + pa_card + ", rs_name="
				+ rs_name + ", con_name=" + con_name + ", r_date=" + r_date + ", r_time=" + r_time + ", pay_method="
				+ pay_method + ", pay_money=" + pay_money + "]";
	}
	

}
