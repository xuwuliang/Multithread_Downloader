package edu.hos.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import edu.hos.model.register_record;

@Controller
public class HosController {
	
	@GetMapping("/")
	public String index(Model model) {
		return "login";
	}
	@GetMapping("/login")//��¼ϵͳ
	public String login(Model model) {
		return "menu";
	}
	@GetMapping("/exit")//�˳�ϵͳ
	public String exit(Model model) {
		return "login";
	}
	
	@GetMapping("/department")//�������ѡ��
	public String de(Model model) {
		return "department";
	}
	
	
	@GetMapping("/register_record")//�����¼
	public String re(Model model) {
		return "register_record";
	}
	@GetMapping("/register")//����Һ�
	public String reg(Model model,int de_id) {
		model.addAttribute("de_id",de_id);
		System.out.println(de_id);
		return "register";
	}
	@GetMapping("/pay")//����֧������
	public String pay(Model model,register_record r) {
		System.out.println(r);
		return "pay";
	}
	@GetMapping("/pay_result")//����֧�����
	public String pay_result(Model model) {
		return "pay_result";
	}
	


}
