package edu.hos.repository;

import org.springframework.stereotype.Repository;

import edu.hos.model.Source_number;

@Repository
public interface Source_numberJdbcRepository {
	
	public Source_number findSource_number(int sc_id) ;

}
