package edu.hos.model;

public class Department {
	 private int de_id;//����id
	   private String de_name;//��������     
	   
	public Department(int de_id, String de_name) {
		super();
		this.de_id = de_id;
		this.de_name = de_name;
	}
	public int getDe_id() {
		return de_id;
	}
	public void setDe_id(int de_id) {
		this.de_id = de_id;
	}
	public String getDe_name() {
		return de_name;
	}
	public void setDe_name(String de_name) {
		this.de_name = de_name;
	}


}
