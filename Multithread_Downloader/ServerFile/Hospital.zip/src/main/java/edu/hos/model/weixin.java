package edu.hos.model;

public class weixin implements pay_method{

	@Override
	public String pay() {
		return "΢��";
	}

}
