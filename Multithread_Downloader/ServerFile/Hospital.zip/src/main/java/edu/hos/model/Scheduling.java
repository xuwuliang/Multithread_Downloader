package edu.hos.model;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Scheduling {
	  private int sc_id;//�Ű���
	  private int do_id;//ҽ�����
	  private Timestamp sc_date;//����
	  private String sc_time;//ʱ���
	  private int  sn_num;//��Դ��
	  public Scheduling() {
		  
	  }
	public Scheduling(int sc_id, int do_id, Timestamp sc_date, String sc_time, int sn_num) {
		super();
		this.sc_id = sc_id;
		this.do_id = do_id;
		this.sc_date = sc_date;
		this.sc_time = sc_time;
		this.sn_num = sn_num;
	}
	public int getSc_id() {
		return sc_id;
	}
	public void setSc_id(int sc_id) {
		this.sc_id = sc_id;
	}
	public int getDo_id() {
		return do_id;
	}
	public void setDo_id(int do_id) {
		this.do_id = do_id;
	}
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Timestamp getSc_date() {
		return sc_date;
	}
	public void setSc_date(Timestamp sc_date) {
		this.sc_date = sc_date;
	}
	public String getSc_time() {
		return sc_time;
	}
	public void setSc_time(String sc_time) {
		this.sc_time = sc_time;
	}
	public int getSn_num() {
		return sn_num;
	}
	public void setSn_num(int sn_num) {
		this.sn_num = sn_num;
	}
	  
	  
	  

}
