package edu.hos.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import edu.hos.model.Doctor;
import edu.hos.model.Patient;
@Component
public class doctorJdbcRepositoryImpl implements doctorJdbcRepository {
	@Autowired
	private JdbcTemplate jt;
	@Override
	public List<Doctor> findDoctor(int de_id, String sc_date, int snt_id) {
		try {
			//return jt.query("select * from doctor_type,Consultation_Room,Department,doctor where doctor_type.do_ty_id=doctor.do_ty_id and Consultation_Room.con_id=doctor.con_id and Department.de_id=doctor.de_id ", new BeanPropertyRowMapper(Doctor.class));
			return jt.query("select * from doctor_type,Consultation_Room,Department,doctor,Scheduling,Source_number where doctor_type.do_ty_id=doctor.do_ty_id and Consultation_Room.con_id=doctor.con_id and Department.de_id=doctor.de_id and doctor.do_id=Scheduling.do_id and Scheduling.sc_id=Source_number.sc_id and doctor.de_id=? and sc_date=? and snt_id=? and sn_num>0", new BeanPropertyRowMapper(Doctor.class),de_id, sc_date, snt_id);
		} catch (EmptyResultDataAccessException e) {
			// TODO: hadministratorandle exception
			return null;
		}
		
	}

}
