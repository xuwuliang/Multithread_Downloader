package edu.hos.model;

public interface Source_number_state {

}
