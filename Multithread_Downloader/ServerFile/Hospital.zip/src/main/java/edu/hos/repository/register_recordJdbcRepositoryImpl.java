package edu.hos.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import edu.hos.model.Doctor;
import edu.hos.model.register_record;
@Component
public class register_recordJdbcRepositoryImpl implements register_recordJdbcRepository {
	@Autowired
	private JdbcTemplate jt;
	@Override
	public int insert(register_record record) {
		jt.update("insert into register_record values(?,null,1,?,?,?,?,?,?)",record.getCon_name(),record.getR_date(),record.getR_time(),record.getPay_method(),record.getPay_money(),record.getPa_card(),record.getDo_name());
		return 1;
	}

	@Override
	public List<register_record> query(String pa_card) {
		try {
			//return jt.query("select * from doctor_type,Consultation_Room,Department,doctor where doctor_type.do_ty_id=doctor.do_ty_id and Consultation_Room.con_id=doctor.con_id and Department.de_id=doctor.de_id ", new BeanPropertyRowMapper(Doctor.class));
			return jt.query("select * from register_record where pa_card=?", new BeanPropertyRowMapper(register_record.class),pa_card);
		} catch (EmptyResultDataAccessException e) {
			// TODO: hadministratorandle exception
			return null;
		}
		
	}

}
