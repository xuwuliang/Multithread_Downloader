package edu.hos.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.stereotype.Repository;

import edu.hos.model.Doctor;

@Repository
public interface doctorJdbcRepository {
	
	public List<Doctor> findDoctor(int de_id,String sc_date,int snt_id);


}
