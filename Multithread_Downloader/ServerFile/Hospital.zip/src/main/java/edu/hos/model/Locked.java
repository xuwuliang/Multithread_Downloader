package edu.hos.model;

public class Locked implements Source_number_state{
	private String ss_name="����";

	public String getSs_name() {
		return ss_name;
	}

	public void setSs_name(String ss_name) {
		this.ss_name = ss_name;
	}
	

}
