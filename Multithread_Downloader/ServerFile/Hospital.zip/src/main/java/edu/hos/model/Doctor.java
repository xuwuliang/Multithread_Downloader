package edu.hos.model;

public class Doctor {
	   private int do_id ;//ҽ�����              
	   private String de_name;//��������            
	   private String con_name;//��������
	   private String do_ty_name;//ҽ������
	   private String do_name;//ҽ������
	   private String do_img;//ҽ��ͷ��
	   private String about;//ҽ�����
	   public Doctor() {
		   
	   }
	public Doctor(int do_id, String de_name, String con_name, String do_ty_name, String do_name, String do_img,
			String about) {
		this.do_id = do_id;
		this.de_name = de_name;
		this.con_name = con_name;
		this.do_ty_name = do_ty_name;
		this.do_name = do_name;
		this.do_img = do_img;
		this.about = about;
	}
	public int getDo_id() {
		return do_id;
	}
	public void setDo_id(int do_id) {
		this.do_id = do_id;
	}
	public String getDe_name() {
		return de_name;
	}
	public void setDe_name(String de_name) {
		this.de_name = de_name;
	}
	public String getCon_name() {
		return con_name;
	}
	public void setCon_name(String con_name) {
		this.con_name = con_name;
	}
	public String getDo_ty_name() {
		return do_ty_name;
	}
	public void setDo_ty_name(String do_ty_name) {
		this.do_ty_name = do_ty_name;
	}
	public String getDo_name() {
		return do_name;
	}
	public void setDo_name(String do_name) {
		this.do_name = do_name;
	}
	public String getDo_img() {
		return do_img;
	}
	public void setDo_img(String do_img) {
		this.do_img = do_img;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	   
}
