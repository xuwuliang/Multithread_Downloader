function enterbookrack(){
	
	document.getElementById("f").src="bookrack.html";
	
	
}
function look3d(){
	
	document.getElementById("f").src="look3dmenu.html";
	
	
}
function home(){
	
	document.getElementById("f").src="homepage/index.html";
	
	
}
function person(){
	
	document.getElementById("f").src="person/person/index.html";
	
	
}
function exshow(){
	
	document.getElementById("f").src="3dshow.html";
	
	
}

